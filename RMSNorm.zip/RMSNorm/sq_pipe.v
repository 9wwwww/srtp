`timescale 1ns/1ns
//===========================================================================
// sq_pipe.v —— 单块32元素平方和7级流水线
//   拍1 输入寄存 → 拍2 平方 → 拍3~7 五级平衡加法树
//   提频机理：把原组合乘法拆成多拍，缩短单拍组合路径
//   实测事实：综合后 AREG/BREG/MREG/PREG=0，寄存器落在 fabric 触发器(FDRE)，
//             并未进入 DSP48E2 内部寄存器；DSP 减少靠平方/归一化互斥复用
//===========================================================================
module sq_pipe #(
	parameter DATA_W = 16,
	parameter LANES  = 32,
	parameter SUM_W  = 60
)(
	input										clk,
	input										rst_n,
	input										in_valid,	//输入有效，随流水线传递
	input		signed [LANES*DATA_W-1:0]		blk,		//单块32个16位尾数
	output	reg signed [SUM_W-1:0]				sq_sum,		//平方和（7拍后有效）
	output	reg									out_valid	//输出有效，与 sq_sum 对齐
);

	reg signed [DATA_W-1:0]    el_q [0:LANES-1];   //拍1：输入寄存（fabric 触发器，非 DSP AREG/BREG）
	reg signed [DATA_W*2-1:0]  d0   [0:LANES-1];   //拍2：平方（32位，fabric 触发器，非 DSP MREG）
	reg signed [SUM_W-1:0]     d1   [0:15];        //拍3：加法树级1（60位）
	reg signed [SUM_W-1:0]     d2   [0:7];         //拍4：加法树级2
	reg signed [SUM_W-1:0]     d3   [0:3];         //拍5：加法树级3
	reg signed [SUM_W-1:0]     d4   [0:1];         //拍6：加法树级4
	reg [6:0]                  vpipe;              //valid 7拍移位链
	integer t;

	always @(posedge clk or negedge rst_n) begin
		if(!rst_n) begin
			sq_sum    <= 0;
			out_valid <= 1'b0;
			vpipe     <= 0;
		end
		else begin
			//拍1：寄存输入
			for(t=0;t<LANES;t=t+1)
				el_q[t] <= blk[t*DATA_W+:DATA_W];
			//拍2：平方（乘法自然宽度32位，结果存 fabric 触发器，非 DSP MREG）
			for(t=0;t<LANES;t=t+1)
				d0[t] <= el_q[t] * el_q[t];
			//拍3：加法树级1，先符号扩展到60位再相加，防止32位相加溢出
			for(t=0;t<16;t=t+1)
				d1[t] <= {{28{d0[2*t][31]}},d0[2*t]} + {{28{d0[2*t+1][31]}},d0[2*t+1]};
			//拍4~6：平衡加法树后3级
			for(t=0;t<8;t=t+1) d2[t] <= d1[2*t] + d1[2*t+1];
			for(t=0;t<4;t=t+1) d3[t] <= d2[2*t] + d2[2*t+1];
			for(t=0;t<2;t=t+1) d4[t] <= d3[2*t] + d3[2*t+1];
			//拍7：根节点输出
			sq_sum <= d4[0] + d4[1];
			//valid 随7级流水线传递；out_valid取vpipe[5]，与拍7 sq_sum更新同拍，不晚一拍
			vpipe     <= {vpipe[5:0], in_valid};
			out_valid <= vpipe[5];
		end
	end

endmodule
