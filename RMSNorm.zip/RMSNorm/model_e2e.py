import math, random
random.seed(7)

BLK, LNS = 28, 32
N = BLK*LNS
FS = 1<<10           # Q5.10
BIAS = 15

# ---- LUT (与 rsqrt_lut.v 同逻辑) ----
ADDR_W=12; DEPTH=2<<ADDR_W; TS=1<<14
def tbl(addr):
    par = addr>>ADDR_W; a = addr & ((1<<ADDR_W)-1)
    M = (1+par)*(1+a/float(1<<ADDR_W))
    return min(int(round(TS*math.sqrt(N)/math.sqrt(M))), (1<<19)-1)

def hw_rsqrt(sq_sum, sq_exp):
    if sq_sum==0: return 0,0
    k = sq_sum.bit_length()-1
    pe = k + sq_exp - 20
    p  = pe & 1
    ee = k - p
    mn = (sq_sum>>(ee-12)) if ee>=12 else (sq_sum<<(12-ee))
    ma = (mn>>p) & ((1<<ADDR_W)-1)
    addr = (p<<ADDR_W)|ma
    im = (tbl(addr)+8)>>4
    ie = 4 - ((ee+sq_exp-20)>>1)
    return im, ie

def run(scale):
    # 生成输入：每块独立指数（真实），尾数 Q5.10
    mant=[]; ereal=[]
    for b in range(BLK):
        e = random.randint(-6, 2)                      # 真实指数
        ereal.append(e)
        row=[random.randint(-2**15, 2**15-1) for _ in range(LNS)]
        # 幅度按 2^e 归一，尾数保持在 Q5.10 含义
        mant.append(row)
    xr=[mant[b][l]*2.0**-10 * 2.0**ereal[b] for b in range(BLK) for l in range(LNS)]

        # ---- 硬件流程 ----
    blk_sum=[sum(m*m for m in mant[b]) for b in range(BLK)]
    blk_exp=[2*ereal[b] for b in range(BLK)]
    mx=max(blk_exp)
    total=sum(blk_sum[b]>>(mx-blk_exp[b]) for b in range(BLK))
    im,ie = hw_rsqrt(total, mx)

    out=[]
    for b in range(BLK):
        te = ereal[b] + ie                    # blk_exp(真实) + inv_exp
        sh = 14 - te
        for l in range(LNS):
            pr = mant[b][l]*im
            q = (pr + (1<<(sh-1)))>>sh if sh>0 else pr<<(-sh)
            out.append(q)

    rms = math.sqrt(sum(v*v for v in xr)/N)
    ref=[v/rms for v in xr]
    err=[abs(out[i]/FS - ref[i]) for i in range(N)]
    return max(err), sum(err)/N, max(abs(v) for v in ref)

worst=0
for t in range(30):
    m,a,pk = run(t)
    worst=max(worst,m)
print("峰值 |x_hat| :", round(pk,3))
print("最大绝对误差 :", worst)
print("LSB          :", 2.0**-10)
print("最大误差(LSB):", round(worst/(2.0**-10),3))
