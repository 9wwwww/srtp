`timescale 1ns/1ns

//===========================================================================
// rsqrt_lut.v —— 归一化平方和 → 归一化系数
//   inv_rms = inv_mant * 2^-14 * 2^inv_exp
//   sq_exp 必须是总平方和的「真实指数」（无偏，不带 15 偏置）
//===========================================================================
module rsqrt_lut #(
    parameter SUM_W    = 60,
    parameter SQ_W     = 16,
    parameter ADDR_W   = 12,
    parameter BLK      = 80,
    parameter LNS      = 32,
    parameter LUT_FILE = "rsqrt_lut.hex"
)(
    input                                clk,
    input                                rst_n,
    input  signed [SQ_W-1:0]             sq_exp,
    input         [SUM_W-1:0]            sq_sum,
    output reg signed [15:0]             inv_mant,
    output reg signed [15:0]             inv_exp
);

localparam DEPTH = 2 << ADDR_W;
localparam N     = BLK * LNS;

reg [18:0] rom [0:DEPTH-1];
initial $readmemh(LUT_FILE, rom);

// 前导一检测：找 sq_sum 的最高有效位
reg [5:0] k;
integer t;
always @(*) begin
    k = 6'd0;
    for(t=0;t<SUM_W;t=t+1)
        if(sq_sum[t]) k = t;
end

wire signed [15:0] ke   = $signed({{10{1'b0}}, k});
wire signed [15:0] pe   = ke + sq_exp - 16'sd20;
wire               par  = pe[0];                              // 0→尾数落[1,2)，1→落[2,4)
wire signed [15:0] ee   = ke - $signed({{15{1'b0}}, pe[0]});   // 归一化指数
wire signed [15:0] shf  = ee - 16'sd12;
wire signed [15:0] shl  = 16'sd12 - ee;

wire [SUM_W-1:0]   mn   = (shf >= 0) ? (sq_sum >> shf) : (sq_sum << shl);
wire [ADDR_W-1:0]  ma   = (mn >> par) & ((1 << ADDR_W) - 1);
wire [ADDR_W:0]    addr = {par, ma};

wire signed [15:0] sum_e = ee + sq_exp - 16'sd20;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        inv_mant <= 16'sd0;
        inv_exp  <= 16'sd0;
    end
    else if(sq_sum == 0) begin
        inv_mant <= 16'sd0;
        inv_exp  <= 16'sd0;
    end
    else begin
        inv_mant <= (rom[addr] + 19'd8) >> 4;
        //+1 补偿 LUT 静态定标 2^14→2^13 的减半，使最终归一化增益不变
        inv_exp  <= 16'sd4 - (sum_e >>> 1) + 16'sd1;
    end
end

endmodule
