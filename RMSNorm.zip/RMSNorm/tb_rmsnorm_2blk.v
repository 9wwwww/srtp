`timescale 1ns / 1ps
//===========================================================================
// tb_rmsnorm_2blk.v  —  整帧验证 + 背靠背连续流 + 下游反压 + 边界帧
//===========================================================================
module tb_rmsnorm_2blk;

	localparam DATA_W = 16;
	localparam EXP_W  = 8;
	localparam LANES  = 32;
	localparam CHUNKS = 40;
	localparam N      = CHUNKS*LANES*2;
	localparam real SC  = 1024.0;      // Q5.10 LSB
	localparam real TOL = 4.0;         // 容差（LSB）

	//----------- DUT 接口 -----------
	reg  clk, rst_n;
	reg  s_valid;
	wire s_ready;
	reg  signed [LANES*DATA_W-1:0] s_mant_0, s_mant_1;
	reg  signed [EXP_W-1:0]        s_exp;            //全局唯一指数
	wire m_valid;
	reg  m_ready;
	wire signed [LANES*DATA_W-1:0] m_data_0, m_data_1;
	wire m_last;

	rmsnorm_2blk #(
		.DATA_W(DATA_W),
		.EXP_W (EXP_W),
		.LANES (LANES),
		.CHUNKS(CHUNKS)
	) dut (
		.clk     (clk),
		.rst_n   (rst_n),
		.s_valid (s_valid),
		.s_ready (s_ready),
		.s_mant_0(s_mant_0),
		.s_mant_1(s_mant_1),
		.s_exp   (s_exp),
		.m_valid (m_valid),
		.m_ready (m_ready),
		.m_data_0(m_data_0),
		.m_data_1(m_data_1),
		.m_last  (m_last)
	);

	initial clk = 0;
	always #5 clk = ~clk;

	//----------- 下游反压开关：press_en=1 时约 25% 的拍拉低 m_ready -----------
	reg press_en;
	always @(negedge clk) begin
		if (press_en) m_ready <= (({$random} % 4) != 0);
		else          m_ready <= 1'b1;
	end

	//----------- 数据 -----------
	reg  signed [15:0] src [0:N-1];
	integer            g_exp;        //整帧统一真实指数
	reg  signed [15:0] got [0:N-1];

	integer out_blk, got_n, last_cnt, outp_cnt;
	integer gl;

	//----------- 背靠背间隙统计 -----------
	integer in_cnt;        // 本帧已接收的输入拍数
	integer gap, max_gap, prev_out, last_out_time;
	integer first_out_time, out_span;   // 一帧输出的时间跨度（反压时会变长）

	//帧时间戳：f0=每帧第一个输出时间，fl=每帧最后输出时间，tin0=第一帧第一个输入时间
	integer f0[0:7], fl[0:7];
	reg [3:0] oseq;
	integer tin0;
	reg got_tin0;

	always @(posedge clk) begin
		// 输出侧采样
		if(m_valid && m_ready) begin
			for(gl=0; gl<LANES; gl=gl+1) begin
				got[out_blk*LANES+gl]     = m_data_0[gl*DATA_W +: DATA_W];
				got[(out_blk+1)*LANES+gl] = m_data_1[gl*DATA_W +: DATA_W];
			end
			if(outp_cnt == 0) begin
				first_out_time = $time;
				f0[oseq] = $time;
			end
			out_span  = $time - first_out_time;
			out_blk   = out_blk + 2;
			got_n     = got_n + 1;
			outp_cnt  = outp_cnt + 1;
			last_out_time = $time;
			if(m_last) begin
				last_cnt = last_cnt + 1;
				fl[oseq] = $time;
				oseq = oseq + 1;
			end
		end
		// 输入侧握手
		if(s_valid && s_ready) begin
			if(!got_tin0) begin tin0 = $time; got_tin0 = 1; end
			in_cnt = in_cnt + 1;
			if(in_cnt == 1 && prev_out > 0) begin
				gap = $time - prev_out;               // 上一帧最后输出拍 -> 本帧第一输入拍
				if(gap > max_gap) max_gap = gap;
			end
		end
	end

	//----------- 数学辅助 -----------
	function real pow2f;
		input integer e;
		integer i;
		begin
			pow2f = 1.0;
			if (e >= 0) for (i = 0; i < e; i = i + 1) pow2f = pow2f * 2.0;
			else        for (i = 0; i > e; i = i - 1) pow2f = pow2f * 0.5;
		end
	endfunction

	function real sqrtf;
		input real v;
		integer i;
		real g;
		begin
			g = (v > 1.0) ? v : 1.0;
			for (i = 0; i < 80; i = i + 1) g = 0.5 * (g + v / g);
			sqrtf = g;
		end
	endfunction

	//----------- 变量 -----------
	integer b, l, c, ii, frame;
	integer t;
	integer err_cnt, total, log_fd;
	real    rms2, ref_rms, v, rq, dlt, maxd;
	real    rq0, rq1, rq2, rq3;

	initial begin
		rst_n    = 0;
		s_valid  = 0;
		m_ready  = 1;
		press_en = 0;
		s_mant_0 = 0; s_mant_1 = 0;
		s_exp    = 8'sd15;
		out_blk  = 0; got_n = 0;
		last_cnt = 0; outp_cnt = 0;
		in_cnt   = 0;
		max_gap  = 0; prev_out = -1; last_out_time = 0;
		oseq = 0; got_tin0 = 0; tin0 = 0;

		log_fd = $fopen("sim_rmsnorm.log", "w");
		if (log_fd == 0) begin
			$display("[FATAL] cannot open sim_rmsnorm.log");
			$finish;
		end

		$display("=== RMSNorm 2blk test start ===");
		$fwrite(log_fd, "=== RMSNorm 2blk test ===\n");

		repeat (3) @(posedge clk);
		rst_n = 1;
		@(posedge clk);

		maxd = 0.0; err_cnt = 0; total = 0;

		for (frame = 0; frame < 8; frame = frame + 1) begin

			// ---- 反压配置：frame 4/5/6 打开反压，其余全速 ----
			press_en = (frame >= 4 && frame <= 6) ? 1'b1 : 1'b0;

			// ---- 造数据（整帧统一真实指数，范围 -5..4）----
			if (frame == 6) begin
				// 边界帧 A：全零输入
				g_exp = 0;
				for (ii = 0; ii < N; ii = ii + 1) src[ii] = 0;
			end
			else if (frame == 7) begin
				// 边界帧 B：只有 1 个元素满幅（输出贴着 sqrt(2560) 上界）
				g_exp = 0;
				for (ii = 0; ii < N; ii = ii + 1) src[ii] = 0;
				src[0] = 16'sd32767;
			end
			else begin
				t = $random; if (t < 0) t = -t;
				g_exp = (t % 10) - 5;                 // -5 .. +4
				for (ii = 0; ii < N; ii = ii + 1)
					src[ii] = $random;
			end

			// ---- 背靠背驱动：不与上一帧留空隙 ----
			in_cnt = 0;
			for (c = 0; c < 40; c = c + 1) begin
				@(negedge clk);
				s_valid = 1'b1;
				for (l = 0; l < LANES; l = l + 1) begin
					s_mant_0[l*DATA_W +: DATA_W] = src[(c*2)*LANES + l];
					s_mant_1[l*DATA_W +: DATA_W] = src[(c*2+1)*LANES + l];
				end
				s_exp = g_exp + 15;
			end
			@(negedge clk);
			s_valid = 1'b0;

			// ---- 等收齐 40 拍输出 ----
			wait (got_n == 40);
			wait (s_ready == 1'b1);

			// ---- 参考模型 ----
			rms2 = 0.0;
			for (ii = 0; ii < N; ii = ii + 1) begin
				v = src[ii] * pow2f(g_exp - 10);
				rms2 = rms2 + v*v;
			end
			rms2 = rms2 / N;
			if (rms2 < 1.0e-30) rms2 = 1.0;
			ref_rms = sqrtf(rms2);

			// ---- 逐点比对 ----
			for (ii = 0; ii < N; ii = ii + 1) begin
				v   = src[ii] * pow2f(g_exp - 10) / ref_rms;
				rq  = v * SC;
				//参考期望同样按 Q5.10 有符号边界钳位：超出范围的理想值本就无法表示，硬件饱和即正确
				if (rq > 32767.0)       rq = 32767.0;
				else if (rq < -32768.0) rq = -32768.0;
				if (ii == 0) rq0 = rq;
				if (ii == 1) rq1 = rq;
				if (ii == 2) rq2 = rq;
				if (ii == 3) rq3 = rq;
				dlt = got[ii] - rq;
				if (dlt < 0.0) dlt = -dlt;

				total = total + 1;
				if (dlt > maxd) maxd = dlt;

				if (dlt > TOL) begin
					err_cnt = err_cnt + 1;
					$display("[MISMATCH] f%0d i=%0d blk=%0d hw=%0d ref=%f diff=%f",
							 frame, ii, ii/LANES, got[ii], rq, dlt);
					$fwrite(log_fd, "MISMATCH f%0d i=%0d blk=%0d hw=%0d ref=%f diff=%f\n",
							frame, ii, ii/LANES, got[ii], rq, dlt);
				end
			end

			$display("--- frame %0d | press=%0d outp=%0d m_last=%0d | out_span=%0d clk | gap=%0d clk | ref_rms=%f ---",
					 frame, press_en, outp_cnt, last_cnt, (out_span/10)+1, gap/10, ref_rms);
			$display("    got[0..3]=%0d %0d %0d %0d  ref=%f %f %f %f",
					 got[0], got[1], got[2], got[3], rq0, rq1, rq2, rq3);
			$fwrite(log_fd, "frame %0d press=%0d gap=%0d ns ref_rms=%f\n",
					frame, press_en, gap, ref_rms);

			// ---- 清零，准备进入下一帧（不留空闲拍）----
			prev_out = last_out_time;
			out_blk  = 0; got_n = 0; outp_cnt = 0;
		end

		$display("=== SUMMARY ===");
		$display(" points   : %0d", total);
		$display(" mismatch : %0d", err_cnt);
		$display(" max_err  : %f LSB", maxd);
		$display(" max gap  : %0d clk  [10ns=1clk 即背靠背无空拍，等于最小值]", max_gap/10);
		$display(" LATENCY F0 (first in -> last out) : %0d clk", (fl[0]-tin0)/10);
		for(frame=1; frame<8; frame=frame+1)
			$display(" FRAME INTERVAL F%0d (first out -> first out): %0d clk", frame, (f0[frame]-f0[frame-1])/10);
		$fwrite(log_fd, "=== SUMMARY ===\npoints=%0d mismatch=%0d max_err=%f max_gap=%0d ns\n",
				total, err_cnt, maxd, max_gap);

		if (err_cnt == 0) $display("*** PASS ***");
		else              $display("*** FAIL ***");

		$fclose(log_fd);
		$finish;
	end

endmodule
