`timescale 1ns/1ns
//===========================================================================
// norm_pipe.v —— 单块32元素归一化3级流水线
//   拍1 寄存输入并算移位量 → 拍2 乘法 → 拍3 四舍五入桶形移位打包
//   提频机理：把原组合乘法拆成多拍，缩短单拍组合路径
//   实测事实：综合后 AREG/BREG/MREG/PREG=0，寄存器落在 fabric 触发器(FDRE)，
//             并未进入 DSP48E2 内部寄存器
//   每级带独立 valid 时钟使能：无有效输入不装填，停止喂入后管内数据干净走完，不被越界x污染
//   stall=1 整条流水线冻结，用于下游反压
//   数值口径与原 norm function 完全一致，正序定位，输出槽t=输入元素t的结果
//===========================================================================
module norm_pipe #(
	parameter DATA_W   = 16,
	parameter LANES    = 32,
	parameter SQ_EXP_W = 9,
	parameter INV_W    = 16
)(
	input										clk,
	input										rst_n,
	input										stall,		//反压冻结：1时流水线保持
	input										in_valid,	//输入有效，随流水线传递
	input		signed [LANES*DATA_W-1:0]		mant_blk,	//单块原始尾数
	input		signed [SQ_EXP_W-1:0]			blk_exp,	//单块真实指数
	input		signed [INV_W-1:0]				inv_mant,	//系数尾数
	input		signed [INV_W-1:0]				inv_exp,	//系数真实指数
	output	reg signed [LANES*DATA_W-1:0]		out_data,	//Q5.10结果（3拍后有效）
	output	reg									out_valid	//输出有效，与 out_data 对齐
);

	reg signed [LANES*DATA_W-1:0]   mant_q;      //拍1：整块尾数寄存
	reg signed [INV_W-1:0]          inv_mant_q;  //拍1：系数尾数寄存
	reg signed [15:0]               shift_q;     //拍1：移位量 = 14-(blk_exp+inv_exp)
	reg signed [DATA_W*2-1:0]       prod_q [0:LANES-1];  //拍2：乘法（32位，fabric 触发器，非 DSP MREG）
	reg signed [15:0]               shift_q2;    //拍2：移位量打拍，与乘法结果对齐
	reg [2:0]                       vpipe;       //valid 3拍移位链，各级作时钟使能
	integer t;
	reg signed [63:0] q;
	reg signed [DATA_W-1:0] sat;   //Q5.10 饱和值（16bit 有符号边界）

	always @(posedge clk or negedge rst_n) begin
		if(!rst_n) begin
			out_data <= 0;
			out_valid<= 1'b0;
			vpipe    <= 0;
		end
		else if(!stall) begin
			//拍1：仅在输入有效时装填（防止停止喂入后装入越界x）
			if(in_valid) begin
				mant_q     <= mant_blk;
				inv_mant_q <= inv_mant;
				shift_q    <= 16'sd14 - ($signed(blk_exp) + inv_exp);
			end

			//拍2：仅当拍1有有效数据时做乘法
			if(vpipe[0]) begin
				for(t=0;t<LANES;t=t+1)
					prod_q[t] <= $signed(mant_q[t*DATA_W+:DATA_W]) * inv_mant_q;
				shift_q2 <= shift_q;
			end

			//拍3：仅当拍2有有效数据时桶形移位打包
			if(vpipe[1]) begin
				for(t=0;t<LANES;t=t+1) begin
					if(shift_q2 > 0)
						//拼接结果默认无符号，须 $signed 使 >>> 做算术右移（保留负号），否则负数被逻辑右移补0而误饱和
						q = $signed({{32{prod_q[t][31]}},prod_q[t]} + (64'sd1 << (shift_q2-1))) >>> shift_q2;
					else
						q = $signed({{32{prod_q[t][31]}},prod_q[t]}) << (-shift_q2);
					//Q5.10 饱和：超出 16bit 有符号边界则钳位，防回绕
					if(q > 64'sd32767)
						sat = 16'sd32767;
					else if(q < -64'sd32768)
						sat = -16'sd32768;
					else
						sat = q[DATA_W-1:0];
					out_data[t*DATA_W+:DATA_W] <= sat;
				end
			end

			//valid 随3级流水线传递；out_valid取vpipe[1]，与拍3 out_data更新同拍，不晚一拍
			vpipe     <= {vpipe[1:0], in_valid};
			out_valid <= vpipe[1];
		end
	end

endmodule
