import math
import sys

ADDR_W   = 12
BLK      = 80
LNS      = 32
N        = BLK * LNS
# 静态定标从 2^14 降到 2^13：N 增大后 sqrt(N) 增益约 1.69x，
# 减半后 inv_mant 仍落在 16bit 内；减半的 2x 由 rsqrt_lut 的 inv_exp +1 补回
OUT_SCALE = 1 << 13
DEPTH    = 2 << ADDR_W
W        = 19

out = sys.argv[1] if len(sys.argv) > 1 else "rsqrt_lut.hex"

def mval(par, a):
    return (1 + par) * (1.0 + a / float(1 << ADDR_W))

vmax = 0
vmin = 1 << 30
with open(out, "w") as f:
    for addr in range(DEPTH):
        par = addr >> ADDR_W
        a   = addr & ((1 << ADDR_W) - 1)
        v = int(round(OUT_SCALE * math.sqrt(N) / math.sqrt(mval(par, a))))
        v = min(v, (1 << W) - 1)
        v = max(v, 0)
        vmax = max(vmax, v)
        vmin = min(vmin, v)
        f.write("%05x\n" % v)

print("file   :", out)
print("depth  :", DEPTH)
print("max    :", vmax, hex(vmax))
print("min    :", vmin, hex(vmin))
print("bits ok:", vmax < (1 << W))
