`timescale 1ns/1ns
//===========================================================================
// v11 统一指数 + 64 宽 chunk 版（在 v10 基础上简化归约）—— 相对 v10 的修改
//   目标模型 Qwen3-4B：hidden=2560，按 64 元素/chunk 切 40 个 chunk。
//   1. 全部 2560 元素共用一个全局指数（接口由双 exp 改为单一 s_exp），不再有 per-block 指数。
//   2. 所有元素同一定点格式，平方和在 sq_pipe 输出时直接 running 累加，
//      去掉 running max 扫描、去掉按指数对齐移位，归约只剩加法。
//   3. 不再需要 bsq/bse/exp 标量 BRAM；全局真实指数只存一个标量寄存器。
//   4. mant 仍按 lane 多 bank BRAM（32 个双端口，A 口前32/B 口后32，合64），
//      BRAM 同步读预读一拍，valid 延迟对齐，stall 时 en=0 保持输出。
//   外部 sq_pipe/norm_pipe/rsqrt_lut 接口不变；数据格式：统一指数块浮点进、Q5.10 定点出。
//===========================================================================
module rmsnorm_2blk #(

	//输入数据相关常量
	parameter DATA_W        = 16,
	parameter EXP_W         = 8,
	parameter LANES         = 32,
	parameter CHUNKS        = 40,    //2560/64
	parameter SUM_W         = 60,    //平方和位宽
	parameter SQ_EXP_W      = EXP_W + 1, //平方后指数位宽（有符号）
	parameter OUT_FRAC      = 10     //输出Q5.10的小数位数
)(
	input													clk,
	input													rst_n,

	//输入数据
	input													s_valid,//上游输入有效
	output													s_ready,//可以接收
	input		signed [LANES*DATA_W-1:0]					s_mant_0,
	input		signed [LANES*DATA_W-1:0]					s_mant_1,
	input		signed [EXP_W-1:0]							s_exp, //全局唯一指数（带偏置）

	//输出数据
	output													m_valid,//输出数据有效
	input													m_ready,//下游可以接收数据
	output	signed [LANES*DATA_W-1:0]						m_data_0,
	output	signed [LANES*DATA_W-1:0]						m_data_1,
	output													m_last
);

localparam INV_W = 16;   //归一化系数位宽
localparam BIAS  = 15;   //输入指数偏置
localparam AW    = 6;    //BRAM 地址位宽，深度 64（实际用 40）

//双缓冲：每个 buf 状态  0=EMPTY 1=FILL 2=READY 3=DRAIN
reg [1:0] bstate [0:1];

//输入引擎状态
localparam I_IN=3'd0, I_SQ=3'd1, I_RLUT=3'd2, I_RDONE=3'd3, I_WAIT=3'd4;
reg [2:0] ist;
reg [6:0] i_in_cnt;    //输入拍计数 0..39
reg [6:0] sqc;         //平方收集计数 0..40
reg       i_buf;

//输出引擎状态
localparam O_IDLE = 1'd0, O_OUT = 1'd1;
reg       ost;
reg [6:0] ar;          //输出读地址：0..40
reg [5:0] o_out;
reg       o_buf;
reg       dv;          //BRAM 数据有效（同步读延迟1拍），norm_in_v=dv&&!stall

//全局真实指数（每 buf 一个标量）
reg signed [EXP_W-1:0] ge0, ge1;

//归约窄寄存器
reg signed [SUM_W-1:0] tot;
reg signed [15:0] inv_m0, inv_m1;
reg signed [15:0] inv_e0, inv_e1;

//全局真实指数与平方指数（去偏置）
wire signed [EXP_W-1:0]    de  = $signed(s_exp) - 8'sd15;
wire signed [SQ_EXP_W-1:0] sse = {de, 1'b0};

//地址
wire [AW-1:0] in_a = i_in_cnt[AW-1:0];
wire [AW-1:0] o_a  = ar[AW-1:0];

//每个 buf 的 BRAM 独立使能：仅当输出引擎正在读该 buf 且 stall 时 en=0 保持，其余 en=1
wire en0 = (o_buf==0 && ost==O_OUT) ? !norm_stall : 1'b1;
wire en1 = (o_buf==1 && ost==O_OUT) ? !norm_stall : 1'b1;

//握手组合
wire s_ready    = (ist == I_IN);
wire sq_in_v    = (ist == I_IN) && s_valid;
wire norm_stall = norm_out_v0 && !m_ready;
wire norm_in_v  = (ost == O_OUT) && dv && !norm_stall;
wire m_valid    = norm_out_v0;
wire m_last     = norm_out_v0 && (o_out == CHUNKS-1);

assign m_data_0 = norm_data_0;
assign m_data_1 = norm_data_1;

//================ 平方流水线（接口不变） ================
wire signed [SUM_W-1:0] sq_sum_0, sq_sum_1;
wire                    sq_out_v0, sq_out_v1;
sq_pipe #(.DATA_W(DATA_W), .LANES(LANES), .SUM_W(SUM_W)) u_sq_0 (
	.clk(clk), .rst_n(rst_n), .in_valid(sq_in_v),
	.blk(s_mant_0), .sq_sum(sq_sum_0), .out_valid(sq_out_v0)
);
sq_pipe #(.DATA_W(DATA_W), .LANES(LANES), .SUM_W(SUM_W)) u_sq_1 (
	.clk(clk), .rst_n(rst_n), .in_valid(sq_in_v),
	.blk(s_mant_1), .sq_sum(sq_sum_1), .out_valid(sq_out_v1)
);

//================ mant 多 bank BRAM（32 个双端口/buf） ================
wire signed [DATA_W-1:0] mqa0 [0:LANES-1], mqb0 [0:LANES-1];
wire signed [DATA_W-1:0] mqa1 [0:LANES-1], mqb1 [0:LANES-1];
genvar g;
generate
	for(g=0; g<LANES; g=g+1) begin: g_m
		//buf0 mant_0（独立 mem，仅用 A 口）
		bram_tdp #(.DW(DATA_W), .AW(AW)) u_a0 (
			.clk(clk), .en(en0),
			.aa((o_buf==0 && ost==O_OUT) ? o_a : in_a), .ab(in_a),
			.wea((i_buf==0 && ist==I_IN && s_valid)), .web(1'b0),
			.da(s_mant_0[g*DATA_W+:DATA_W]), .db(0),
			.qa(mqa0[g]), .qb()
		);
		//buf0 mant_1（独立 mem）
		bram_tdp #(.DW(DATA_W), .AW(AW)) u_b0 (
			.clk(clk), .en(en0),
			.aa((o_buf==0 && ost==O_OUT) ? o_a : in_a), .ab(in_a),
			.wea((i_buf==0 && ist==I_IN && s_valid)), .web(1'b0),
			.da(s_mant_1[g*DATA_W+:DATA_W]), .db(0),
			.qa(mqb0[g]), .qb()
		);
		//buf1 mant_0（独立 mem）
		bram_tdp #(.DW(DATA_W), .AW(AW)) u_a1 (
			.clk(clk), .en(en1),
			.aa((o_buf==1 && ost==O_OUT) ? o_a : in_a), .ab(in_a),
			.wea((i_buf==1 && ist==I_IN && s_valid)), .web(1'b0),
			.da(s_mant_0[g*DATA_W+:DATA_W]), .db(0),
			.qa(mqa1[g]), .qb()
		);
		//buf1 mant_1（独立 mem）
		bram_tdp #(.DW(DATA_W), .AW(AW)) u_b1 (
			.clk(clk), .en(en1),
			.aa((o_buf==1 && ost==O_OUT) ? o_a : in_a), .ab(in_a),
			.wea((i_buf==1 && ist==I_IN && s_valid)), .web(1'b0),
			.da(s_mant_1[g*DATA_W+:DATA_W]), .db(0),
			.qa(mqb1[g]), .qb()
		);
	end
endgenerate

//================ 输出组合：选 o_buf 拼回两块 ================
reg signed [LANES*DATA_W-1:0] rdb0, rdb1;
reg signed [SQ_EXP_W-1:0] bexp0, bexp1;
integer rl;
always @(*) begin
	for(rl=0; rl<LANES; rl=rl+1) begin
		rdb0[rl*DATA_W+:DATA_W] = o_buf ? mqa1[rl] : mqa0[rl];
		rdb1[rl*DATA_W+:DATA_W] = o_buf ? mqb1[rl] : mqb0[rl];
	end
	//统一全局真实指数，符号扩展到 9bit
	bexp0 = o_buf ? {{1{ge1[7]}}, ge1} : {{1{ge0[7]}}, ge0};
	bexp1 = bexp0;
end

//================ 归一化流水线（接口不变） ================
wire signed [LANES*DATA_W-1:0] norm_data_0, norm_data_1;
wire                           norm_out_v0, norm_out_v1;
norm_pipe #(.DATA_W(DATA_W), .LANES(LANES), .SQ_EXP_W(SQ_EXP_W), .INV_W(INV_W)) u_norm_0 (
	.clk(clk), .rst_n(rst_n), .stall(norm_stall), .in_valid(norm_in_v),
	.mant_blk(rdb0), .blk_exp(bexp0),
	.inv_mant(o_buf ? inv_m1 : inv_m0), .inv_exp(o_buf ? inv_e1 : inv_e0),
	.out_data(norm_data_0), .out_valid(norm_out_v0)
);
norm_pipe #(.DATA_W(DATA_W), .LANES(LANES), .SQ_EXP_W(SQ_EXP_W), .INV_W(INV_W)) u_norm_1 (
	.clk(clk), .rst_n(rst_n), .stall(norm_stall), .in_valid(norm_in_v),
	.mant_blk(rdb1), .blk_exp(bexp1),
	.inv_mant(o_buf ? inv_m1 : inv_m0), .inv_exp(o_buf ? inv_e1 : inv_e0),
	.out_data(norm_data_1), .out_valid(norm_out_v1)
);

//================ epsilon 定点项（统一指数口径） ================
//真实平方和=tot×2^(2E-30)，eps≈2^-20 → eps_q=2^(10-2E)；正常数据下低于1LSB，主要防除零
wire signed [SUM_W-1:0] eps_tot = (10-2*de >= 0) ? (60'sd1 << (10-2*de)) : 0;

//================ 查表（输入 tot/平方指数，下一拍出 inv） ================
wire signed [INV_W-1:0] inv_rms_mant, inv_rms_exp;
rsqrt_lut #(
	.SUM_W(SUM_W), .SQ_W(SQ_EXP_W), .ADDR_W(12),
	.BLK(CHUNKS), .LNS(LANES), .LUT_FILE("rsqrt_lut.hex")
) u_rsqrt_lut (
	.clk(clk), .rst_n(rst_n),
	.sq_exp(sse), .sq_sum(tot + eps_tot),
	.inv_mant(inv_rms_mant), .inv_exp(inv_rms_exp)
);

always @(posedge clk, negedge rst_n) begin
	if(!rst_n) begin
		ist       <= I_IN;
		ost       <= O_IDLE;
		i_in_cnt  <= 0;
		sqc       <= 0;
		ar        <= 0;
		o_out     <= 0;
		tot       <= 0;
		dv        <= 0;
		i_buf     <= 0;
		o_buf     <= 0;
		ge0       <= 0; ge1 <= 0;
		bstate[0] <= 1;
		bstate[1] <= 0;
	end
	else begin

		//================ 输入引擎 ================
		case(ist)

			I_IN: begin
				if(s_valid) begin
					if(i_buf==0) ge0 <= de; else ge1 <= de;
					if(i_in_cnt == CHUNKS-1) begin
						i_in_cnt <= 0;
						ist      <= I_SQ;
					end
					else
						i_in_cnt <= i_in_cnt + 7'd1;
				end
			end

			//等 sq 流水排空，tot 已 running 累加
			I_SQ: begin
				if(sqc == CHUNKS) begin
					ist <= I_RLUT;
				end
			end

			//查表拍：rsqrt 内部处理，下一拍存
			I_RLUT: begin
				ist <= I_RDONE;
			end

			//存系数、置 READY、衔接下一帧
			I_RDONE: begin
				if(i_buf == 0) begin
					inv_m0    <= inv_rms_mant;
					inv_e0    <= inv_rms_exp;
					bstate[0] <= 2'd2;
					if(bstate[1] == 2'd0) begin
						i_buf <= 1; bstate[1] <= 2'd1; ist <= I_IN;
					end
					else ist <= I_WAIT;
				end
				else begin
					inv_m1    <= inv_rms_mant;
					inv_e1    <= inv_rms_exp;
					bstate[1] <= 2'd2;
					if(bstate[0] == 2'd0) begin
						i_buf <= 0; bstate[0] <= 2'd1; ist <= I_IN;
					end
					else ist <= I_WAIT;
				end
				sqc <= 0;
				tot <= 0;
			end

			I_WAIT: begin
				if(i_buf == 0) begin
					if(bstate[1] == 2'd0) begin
						i_buf <= 1; bstate[1] <= 2'd1; ist <= I_IN;
					end
				end
				else begin
					if(bstate[0] == 2'd0) begin
						i_buf <= 0; bstate[0] <= 2'd1; ist <= I_IN;
					end
				end
			end

		endcase

		//平方和 running 累加（同格式直接加，无对齐）
		if(sq_out_v0 && sqc < CHUNKS) begin
			tot <= tot + sq_sum_0 + sq_sum_1;
			sqc <= sqc + 7'd1;
		end

		//================ 输出引擎 ================
		case(ost)
			O_IDLE: begin
				if(bstate[0] == 2'd2) begin
					o_buf     <= 0;
					bstate[0] <= 2'd3;
					ar        <= 0;
					dv        <= 0;
					ost       <= O_OUT;
				end
				else if(bstate[1] == 2'd2) begin
					o_buf     <= 1;
					bstate[1] <= 2'd3;
					ar        <= 0;
					dv        <= 0;
					ost       <= O_OUT;
				end
			end

			O_OUT: begin
				//BRAM 同步读：ar 给地址，en=!stall；stall 时 en=0 输出保持，dv 冻结
				if(!norm_stall) begin
					if(ar < CHUNKS) begin
						ar <= ar + 7'd1;
						dv <= 1'b1;
					end
					else begin
						dv <= 1'b0;
					end
				end
				if(norm_out_v0 && m_ready) begin
					if(o_out == CHUNKS-1) begin
						bstate[o_buf] <= 2'd0;
						ost     <= O_IDLE;
						ar      <= 0;
						o_out   <= 0;
						dv      <= 0;
					end
					else
						o_out <= o_out + 6'd1;
				end
			end
		endcase

	end
end

endmodule
