`timescale 1ns/1ns
//===========================================================================
// bram_tdp.v —— 真双端口块存储器（BRAM）推断模板
//   两个端口各自独立：同步写 + 同步读（地址在时钟沿，下一拍出数据，比 LUTRAM 多一级读）
//   两个 always 各只处理一个端口，符合 Vivado Block RAM 推断模板，映射 RAMB18/36
//   端口 A/B 可在同一拍读两个不同地址，用于一拍取偶/奇两块
//   en 为双端口共用使能：en=1 正常读/写；en=0 时输出 qa/qb 保持、不写。
//   用途：下游反压 stall 时 en=0，让 BRAM 输出保持"待装填块"，避免同步读在 stall 下错位。
//===========================================================================
module bram_tdp #(
	parameter DW = 16,
	parameter AW = 7          //深度 2^AW
)(
	input										clk,
	input										en,
	input				[AW-1:0]				aa, ab,
	input										wea, web,
	input	signed	[DW-1:0]					da, db,
	output	reg signed [DW-1:0]					qa, qb
);

	(* ram_style = "block" *) reg signed [DW-1:0] mem [0:(1<<AW)-1];

	always @(posedge clk) begin
		if(en) begin
			if(wea)
				mem[aa] <= da;
			qa <= mem[aa];
		end
	end

	always @(posedge clk) begin
		if(en) begin
			if(web)
				mem[ab] <= db;
			qb <= mem[ab];
		end
	end

endmodule
