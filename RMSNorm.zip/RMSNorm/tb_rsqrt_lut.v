`timescale 1ns / 1ps
//===========================================================================
// tb_rsqrt_lut.v  —  rsqrt 查表验证：扫描 + 相对误差统计 + 日志
//===========================================================================
module tb_rsqrt_lut;

    localparam integer SUM_W  = 60;
    localparam integer ADDR_W = 12;
    localparam integer BLK    = 28;
    localparam integer LNS    = 32;
    localparam integer N      = BLK * LNS;
    localparam real    FSC    = 16384.0;      // Q1.14 定标

    //----------- DUT 接口 -----------
    reg                clk;
    reg                rst_n;
    reg  signed [15:0] sq_exp;
    reg         [SUM_W-1:0] sq_sum;
    wire signed [15:0] inv_mant;
    wire signed [15:0] inv_exp;

    rsqrt_lut #(
        .SUM_W   (SUM_W),
        .ADDR_W  (ADDR_W),
        .BLK     (BLK),
        .LNS     (LNS),
        .LUT_FILE("rsqrt_lut.hex")
    ) u_rsqrt_lut (
        .clk     (clk),
        .rst_n   (rst_n),
        .sq_exp  (sq_exp),
        .sq_sum  (sq_sum),
        .inv_mant(inv_mant),
        .inv_exp (inv_exp)
    );

    //----------- 时钟 -----------
    initial clk = 0;
    always #5 clk = ~clk;

    //----------- 数学辅助 -----------
    function real pow2f;
        input integer e;
        integer i;
        begin
            pow2f = 1.0;
            if (e >= 0) for (i = 0; i < e; i = i + 1) pow2f = pow2f * 2.0;
            else        for (i = 0; i > e; i = i - 1) pow2f = pow2f * 0.5;
        end
    endfunction

    function real sqrtf;
        input real v;
        integer i;
        real g;
        begin
            g = (v > 1.0) ? v : 1.0;
            for (i = 0; i < 60; i = i + 1) g = 0.5 * (g + v / g);
            sqrtf = g;
        end
    endfunction

    // 参考值：inv_rms = sqrt(N / Q2)，Q2 = sq_sum * 2^(sq_exp-20)
    function real ref_inv;
        input [SUM_W-1:0] s;
        input integer     ex;
        real q2;
        begin
            q2 = (s * 1.0) * pow2f(ex - 20);
            ref_inv = sqrtf(N / q2);
        end
    endfunction

    //----------- 统计 + 日志 -----------
    integer err_cnt, total, log_fd;
    real    max_rel, cur_rel;

    `ifdef DUMP
    initial begin
        $dumpfile("wave.vcd");
        $dumpvars(0, tb_rsqrt_lut);
    end
    `endif

    // 单点检查任务
    task check;
        input [63:0]   sv;
        input integer  ex;
        integer yi, ei;
        real    hwv, refv;
        begin
            @(negedge clk);
            sq_sum = sv[SUM_W-1:0];
            sq_exp = ex;
            @(posedge clk);
            #1;

            yi   = inv_mant;
            ei   = inv_exp;
            hwv  = (yi * 1.0) / FSC * pow2f(ei);
            refv = ref_inv(sv[SUM_W-1:0], ex);

            total = total + 1;
            cur_rel = (hwv > refv) ? ((hwv - refv) / refv) : ((refv - hwv) / refv);
            if (cur_rel > max_rel) max_rel = cur_rel;

            if (cur_rel > 1.0e-3) begin
                err_cnt = err_cnt + 1;
                $display("[MISMATCH] sum=%0d exp=%0d hw=%0d(2^%0d)=%f ref=%f rel=%e",
                         sv, ex, yi, ei, hwv, refv, cur_rel);
                $fwrite(log_fd, "MISMATCH sum=%0d exp=%0d hw=%0d exp2=%0d hwv=%f ref=%f rel=%e\n",
                        sv, ex, yi, ei, hwv, refv, cur_rel);
            end
        end
    endtask

    //----------- 主流程 -----------
    integer kk, jj;
    reg [63:0] bs;

    initial begin
        sq_sum = 0; sq_exp = 20; rst_n = 0;
        err_cnt = 0; total = 0; max_rel = 0.0;

        log_fd = $fopen("sim_rsqrt.log", "w");
        if (log_fd == 0) begin
            $display("[FATAL] cannot open sim_rsqrt.log");
            $finish;
        end

        repeat (3) @(posedge clk);
        rst_n = 1;
        @(posedge clk); #1;

        $display("=== rsqrt LUT test start ===");
        $fwrite(log_fd, "=== rsqrt LUT test ===\n");

        // 第一轮：指数固定，扫平方和量级与尾数
        for (kk = 0; kk <= 54; kk = kk + 1) begin
            bs = 64'd1 << kk;
            for (jj = 0; jj < 4; jj = jj + 1) begin
                check(bs + ((bs >> 2) * jj), 20);
            end
        end

        // 第二轮：平方和固定，扫指数
        for (kk = 0; kk < 3; kk = kk + 1) begin
            bs = (64'd1 << 32) + ((64'd1 << 32) >> 3) * kk;
            for (jj = -6; jj <= 40; jj = jj + 1) begin
                check(bs, jj);
            end
        end

        // 边界：最高位为 0 且指数为奇（会落到负的归一化指数）
        check(64'd1, 19);
        check(64'd1, 21);
        check(64'd3, 19);
        check(64'd7, 15);

        // 边界：全零
        check(64'd0, 20);

        $display("=== SUMMARY ===");
        $display(" total    : %0d", total);
        $display(" mismatch : %0d", err_cnt);
        $display(" max_rel  : %e", max_rel);
        $fwrite(log_fd, "=== SUMMARY ===\ntotal=%0d mismatch=%0d max_rel=%e\n",
                total, err_cnt, max_rel);

        if (err_cnt == 0) $display("*** PASS ***");
        else              $display("*** FAIL ***");

        $fclose(log_fd);
        $finish;
    end

endmodule
